import React from 'react';
import './App.css';
// import Bootstrap from 'react-bootstrap';


function Bio() {
  return (
    <header>Test</header>
    
  );
}

export default Bio;